
import React, { useState, useRef } from 'react';
import { DISASTER_TOPICS } from './constants';
import DisasterInfoCard from './components/DisasterInfoCard';
import ChatInterface from './components/ChatInterface';
import ImagePromptModal from './components/ImagePromptModal';
import { ImagePromptInfo } from './types';
import FeedbackModal from './components/FeedbackModal';

interface ChatInterfaceHandle {
  sendMessage: (prompt: string) => void;
  generateImage: (promptInfo: ImagePromptInfo) => void;
}

const App: React.FC = () => {
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const chatInterfaceRef = useRef<ChatInterfaceHandle>(null);

  const handleCardClick = (prompt: string) => {
    if (prompt === 'ACTION_GENERATE_IMAGE') {
      setIsImageModalOpen(true);
    } else {
      if (chatInterfaceRef.current) {
          chatInterfaceRef.current.sendMessage(prompt);
      }
    }
  };

  const handleImagePromptSelect = (promptInfo: ImagePromptInfo) => {
    setIsImageModalOpen(false);
    if (chatInterfaceRef.current) {
      chatInterfaceRef.current.generateImage(promptInfo);
    }
  };

  return (
    <div className="flex flex-col h-screen font-sans bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
      <header className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-center items-center relative">
        <div className="text-center">
            <h1 className="text-2xl md:text-3xl font-bold text-emerald-600 dark:text-emerald-400">Sahara</h1>
            <p className="text-sm md:text-base text-slate-500 dark:text-slate-400">Your AI Disaster Awareness Assistant</p>
        </div>
        <div className="absolute right-4 top-1/2 -translate-y-1/2">
            <button
                onClick={() => setIsFeedbackModalOpen(true)}
                className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                aria-label="Submit Feedback"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
            </button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden flex flex-col">
        <ChatInterface ref={chatInterfaceRef} onOpenImageModal={() => setIsImageModalOpen(true)} />
      </main>

      {/* This section will be hidden by the chat on small screens */}
      <div className="hidden lg:block absolute top-1/2 left-4 -translate-y-1/2 p-4 space-y-4">
         <h2 className="text-lg font-semibold text-slate-600 dark:text-slate-300 mb-2">Quick Topics</h2>
        {DISASTER_TOPICS.map((topic) => (
          <DisasterInfoCard key={topic.name} info={topic} onClick={handleCardClick} />
        ))}
      </div>

      <ImagePromptModal 
        isOpen={isImageModalOpen}
        onClose={() => setIsImageModalOpen(false)}
        onSelect={handleImagePromptSelect}
      />

      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
      />
    </div>
  );
};

export default App;
