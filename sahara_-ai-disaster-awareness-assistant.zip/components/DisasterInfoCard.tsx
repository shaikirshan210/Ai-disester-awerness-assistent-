
import React from 'react';
import { DisasterInfo } from '../types';

interface DisasterInfoCardProps {
  info: DisasterInfo;
  onClick: (prompt: string) => void;
}

const DisasterInfoCard: React.FC<DisasterInfoCardProps> = ({ info, onClick }) => {
  return (
    <button
      onClick={() => onClick(info.prompt)}
      className="flex items-center p-3 w-full max-w-xs bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
    >
      <div className="flex-shrink-0">
        {info.icon}
      </div>
      <div className="ml-4">
        <p className="text-md font-semibold text-slate-700 dark:text-slate-200 text-left">{info.name}</p>
      </div>
    </button>
  );
};

export default DisasterInfoCard;
