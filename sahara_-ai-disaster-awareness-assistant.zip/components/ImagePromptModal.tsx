import React from 'react';
import { IMAGE_PROMPTS } from '../constants';
import { ImagePromptInfo } from '../types';

interface ImagePromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (prompt: ImagePromptInfo) => void;
}

const ImagePromptModal: React.FC<ImagePromptModalProps> = ({ isOpen, onClose, onSelect }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center backdrop-blur-sm"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 m-4 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">Visualize Safety: Choose an Image</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        <p className="text-slate-600 dark:text-slate-400 mb-6">Select a prompt to generate an awareness image. The image will appear in your chat.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {IMAGE_PROMPTS.map((promptInfo) => (
            <button
              key={promptInfo.title}
              onClick={() => onSelect(promptInfo)}
              className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg text-left hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <h3 className="font-semibold text-emerald-600 dark:text-emerald-400">{promptInfo.title}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{promptInfo.description}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImagePromptModal;
