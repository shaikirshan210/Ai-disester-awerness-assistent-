
import React from 'react';
import { ChatMessage, MessageAuthor, Source } from '../types';

interface MessageProps {
  message: ChatMessage;
}

const LoadingIndicator: React.FC = () => (
  <div className="flex items-center space-x-1 p-2">
    <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
    <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
    <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
  </div>
);

const Sources: React.FC<{ sources: Source[] | undefined }> = ({ sources }) => {
    if (!sources || sources.length === 0) return null;

    return (
        <div className="mt-3 pt-3 border-t border-slate-300/30 dark:border-slate-600/50">
            <h4 className="text-sm font-semibold mb-1">Sources:</h4>
            <ul className="list-disc list-inside space-y-1">
                {sources.map((source, index) => (
                    <li key={index} className="text-sm">
                        <a
                            href={source.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline hover:opacity-80 transition-opacity break-all"
                        >
                            {source.title}
                        </a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const Message: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.author === MessageAuthor.USER;

  const bubbleClasses = isUser
    ? 'bg-emerald-500 text-white self-end rounded-br-none'
    : 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 self-start rounded-bl-none';

  const containerClasses = isUser ? 'justify-end' : 'justify-start';

  return (
    <div className={`flex w-full ${containerClasses} my-1`}>
      <div className={`max-w-xs md:max-w-md lg:max-w-2xl px-4 py-3 rounded-2xl shadow ${bubbleClasses}`}>
        {message.isLoading ? <LoadingIndicator /> : (
            <>
                {message.imageUrl ? (
                    <div>
                        {message.text && <p className="mb-2 whitespace-pre-wrap break-words">{message.text}</p>}
                        <img src={message.imageUrl} alt={message.text || 'Generated awareness image'} className="rounded-lg mt-1" />
                    </div>
                ) : (
                    <div className="whitespace-pre-wrap break-words">{message.text}</div>
                )}
                <Sources sources={message.sources} />
            </>
        )}
      </div>
    </div>
  );
};

export default Message;
