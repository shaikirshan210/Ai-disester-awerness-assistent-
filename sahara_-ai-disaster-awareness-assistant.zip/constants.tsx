
import React from 'react';
import { DisasterInfo, ImagePromptInfo } from './types';

export const SYSTEM_INSTRUCTION = `You are "Sahara", an intelligent and compassionate AI Disaster Awareness Assistant designed to educate and assist users in understanding and preparing for natural and human-made disasters.

Your role is to:
1. Raise Awareness: Provide accurate, up-to-date, and practical information about different disasters (e.g., earthquakes, floods, cyclones, wildfires, pandemics, etc.).
2. Guide Preparedness: Offer step-by-step safety tips, emergency checklists, and precautionary measures before, during, and after a disaster.
3. Support Education: Explain causes, effects, and preventive measures in simple, clear, and interactive language suitable for general users or students.
4. Assist Users Kindly: Maintain an empathetic, calm, and reassuring tone—especially when users express fear or anxiety.
5. Encourage Community Action: Suggest ways users can contribute to disaster relief, community safety programs, or environmental sustainability.

Response Style Guidelines:
- Use simple, informative, and human-like language.
- Provide concise, factual, and helpful answers—avoid technical jargon unless the user requests it.
- Use Markdown for formatting, especially lists, to make information easy to digest.
- Maintain a positive and supportive tone.
- When asked for location-specific advice, recommend verified sources like NDMA, FEMA, or WHO.
- If you don’t have enough data, respond with: “I don’t have the latest details on that, but you can check your local disaster management authority or official website for updates.”`;

export const IMAGE_PROMPTS: ImagePromptInfo[] = [
  {
    title: 'Hopeful Hero Banner',
    description: 'A banner showing diverse people learning about disaster safety with AI.',
    prompt: 'A realistic, hopeful illustration showing diverse people learning about disaster safety with digital technology — an AI assistant on a large screen helping them understand earthquake, flood, and fire preparedness. The background shows a safe city and nature elements. Bright, modern, educational design.',
  },
  {
    title: 'Disaster Awareness Collage',
    description: 'An infographic-style image showing icons for various natural disasters.',
    prompt: 'A clean, modern infographic-style image showing various natural disasters — earthquake, flood, cyclone, wildfire — with icons and short safety symbols like first aid kit, warning signs, emergency phone. Use blue and orange color tones for awareness theme.',
  },
  {
    title: 'Emergency Kit',
    description: 'A high-quality image of a neatly arranged emergency kit.',
    prompt: 'High-quality image of a neatly arranged emergency kit including flashlight, water bottle, first aid box, radio, batteries, food packets, and emergency contact card on a table. Bright lighting and clear labeling.',
  },
  {
    title: 'Family Safety Practice',
    description: 'An illustration of a family practicing an earthquake drill at home.',
    prompt: 'Illustration of a family practicing earthquake safety under a sturdy table with calm expressions, safety posters on walls, and AI assistant screen guiding them. Friendly, educational, and hopeful tone.',
  },
  {
    title: 'AI in Disaster Management',
    description: 'A futuristic image of AI analyzing disaster data on holographic screens.',
    prompt: 'Futuristic AI assistant analyzing real-time disaster data on holographic screens, showing maps, rescue routes, and alerts. Background includes emergency response team and drones. Professional and optimistic tone.',
  },
  {
    title: 'Community Resilience',
    description: 'An illustration of people working together to prevent future disasters.',
    prompt: 'Illustration of people planting trees, cleaning surroundings, and building flood-resistant homes, symbolizing community resilience and prevention. Warm sunlight and positive energy.',
  },
];

export const DISASTER_TOPICS: DisasterInfo[] = [
  {
    name: 'Earthquakes',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-amber-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0zM4 4l3 3m10 10l3 3M4 14l3-3m4-10l3 3" /></svg>,
    prompt: 'What should I do during an earthquake?',
  },
  {
    name: 'Floods',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15zM3 15a4 4 0 004 4m-4-4v-2m18 2v-2" /></svg>,
    prompt: 'How can I prepare for a flood?',
  },
  {
    name: 'Wildfires',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7.C14.05 5.02 16 7.03 16 9c1 0 3-1.18 3 3 0 .5-1 2.98-2.343 4.657z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" /></svg>,
    prompt: 'What causes wildfires?',
  },
  {
    name: 'Emergency Kits',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>,
    prompt: 'How do I build an emergency kit?',
  },
  {
    name: 'Get Involved',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path strokeLinecap="round" strokeLinejoin="round" d="M23 21v-2a4 4 0 00-3-3.87" /><path strokeLinecap="round" strokeLinejoin="round" d="M16 3.13a4 4 0 010 7.75" /></svg>,
    prompt: 'How can I contribute to community safety and disaster relief efforts?',
  },
  {
    name: 'Visualize Safety',
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
    prompt: 'ACTION_GENERATE_IMAGE',
  },
];
