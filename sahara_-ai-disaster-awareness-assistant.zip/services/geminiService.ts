
import { GoogleGenAI, Chat, GenerateContentResponse, Modality } from "@google/genai";
import { SYSTEM_INSTRUCTION } from '../constants';
import { Source } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

let chat: Chat | null = null;

function getChatSession(): Chat {
    if (!chat) {
        chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
            },
        });
    }
    return chat;
}

export interface SaharaResponse {
    text: string;
    sources?: Source[];
}

function extractSources(response: GenerateContentResponse): Source[] {
    const sources: Source[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
        for (const chunk of chunks) {
            if (chunk.web) {
                sources.push({ uri: chunk.web.uri, title: chunk.web.title || chunk.web.uri });
            } else if (chunk.maps) {
                sources.push({ uri: chunk.maps.uri, title: chunk.maps.title || 'View on Google Maps' });
            }
        }
    }
    // Deduplicate sources by URI
    return [...new Map(sources.map(item => [item.uri, item])).values()];
}

export async function getSaharaResponse(
    prompt: string, 
    location?: { latitude: number; longitude: number }
): Promise<SaharaResponse> {
    if (location) {
        // Use stateless, grounded call for location-specific queries
        try {
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
                config: {
                    systemInstruction: SYSTEM_INSTRUCTION,
                    tools: [{ googleSearch: {} }, { googleMaps: {} }],
                    toolConfig: {
                        retrievalConfig: {
                            latLng: {
                                latitude: location.latitude,
                                longitude: location.longitude
                            }
                        }
                    }
                },
            });
            return {
                text: response.text,
                sources: extractSources(response),
            };
        } catch (error) {
            console.error("Grounded Gemini API error:", error);
            return { text: "I'm sorry, I couldn't fetch local alerts right now. Please try again later." };
        }
    } else {
        // Use existing chat session for conversational queries
        const chatSession = getChatSession();
        try {
            const response = await chatSession.sendMessage({ message: prompt });
            return { text: response.text };
        } catch (error) {
            console.error("Chat Gemini API error:", error);
            // Reset chat session on error
            chat = null;
            return { text: "I'm sorry, I'm having trouble connecting right now. Could you please try your request again?" };
        }
    }
}

export async function generateSaharaImage(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data found in Gemini response");

    } catch (error) {
        console.error("Image generation Gemini API error:", error);
        throw new Error("I'm sorry, I couldn't generate the image right now. Please try again later.");
    }
}
