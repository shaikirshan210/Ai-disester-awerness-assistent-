import React from 'react';

export enum MessageAuthor {
  USER = 'user',
  SAHARA = 'sahara',
}

export interface Source {
  uri: string;
  title: string;
}

export interface ChatMessage {
  id: string;
  author: MessageAuthor;
  text: string;
  isLoading?: boolean;
  sources?: Source[];
  imageUrl?: string;
}

export interface DisasterInfo {
    name: string;
    // FIX: Using React.ReactElement instead of JSX.Element to explicitly reference the React namespace and resolve the "Cannot find namespace 'JSX'" error.
    icon: React.ReactElement;
    prompt: string;
}

export interface ImagePromptInfo {
    title: string;
    prompt: string;
    description: string;
}
